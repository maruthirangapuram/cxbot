import { Project } from '../types';

// Mock data to simulate database content
export const mockProjects: Project[] = [
  {
    id: 'PRJ-001',
    name: 'Online Banking Portal',
    description: 'Main customer-facing online banking application',
    lastScan: '2025-01-15',
    vulnerabilities: {
      high: 3,
      medium: 7,
      low: 12
    },
    status: 'Completed',
    owner: 'Sarah Johnson',
    created: '2024-10-01'
  },
  {
    id: 'PRJ-002',
    name: 'Payment Processing API',
    description: 'Backend API for processing customer payments',
    lastScan: '2025-01-10',
    vulnerabilities: {
      high: 1,
      medium: 4,
      low: 8
    },
    status: 'Completed',
    owner: 'Michael Chen',
    created: '2024-09-15'
  },
  {
    id: 'PRJ-003',
    name: 'Mobile Banking App',
    description: 'iOS and Android mobile banking application',
    lastScan: '2025-01-05',
    vulnerabilities: {
      high: 2,
      medium: 9,
      low: 5
    },
    status: 'Completed',
    owner: 'Jessica Williams',
    created: '2024-11-20'
  },
  {
    id: 'PRJ-004',
    name: 'Internal Admin Dashboard',
    description: 'Administrative dashboard for internal bank employees',
    lastScan: '2024-12-28',
    vulnerabilities: {
      high: 0,
      medium: 3,
      low: 7
    },
    status: 'In Progress',
    owner: 'Robert Taylor',
    created: '2024-12-01'
  },
  {
    id: 'PRJ-005',
    name: 'Customer Identity Service',
    description: 'Identity management and authentication service',
    lastScan: '2024-12-20',
    vulnerabilities: {
      high: 5,
      medium: 8,
      low: 3
    },
    status: 'Completed',
    owner: 'Emily Davis',
    created: '2024-10-15'
  }
];
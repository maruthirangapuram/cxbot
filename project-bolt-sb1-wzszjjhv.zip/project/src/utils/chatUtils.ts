import { Message, Project } from '../types';
import { mockProjects } from '../data/mockProjects';

export const generateResponse = (query: string, selectedProject: Project | null): string => {
  const normalizedQuery = query.toLowerCase();
  
  // Project selection logic
  const projectIdMatch = normalizedQuery.match(/project (\w+-\d+)/i);
  if (projectIdMatch) {
    const projectId = projectIdMatch[1].toUpperCase();
    const project = mockProjects.find(p => p.id === projectId);
    if (project) {
      return `I've selected project ${project.name} (${project.id}) for you. What would you like to know about it?`;
    } else {
      return `I couldn't find a project with ID ${projectId}. Please try another project ID or ask about available projects.`;
    }
  }
  
  if (normalizedQuery.includes('list all projects') || normalizedQuery.includes('show projects')) {
    return `Here are the available projects:\n${mockProjects.map(p => `- ${p.name} (${p.id})`).join('\n')}`;
  }
  
  // If a project is selected, answer questions about it
  if (selectedProject) {
    if (normalizedQuery.includes('vulnerabilities') || normalizedQuery.includes('security issues')) {
      const { high, medium, low } = selectedProject.vulnerabilities;
      const total = high + medium + low;
      return `Project ${selectedProject.name} has ${total} total vulnerabilities: ${high} high, ${medium} medium, and ${low} low severity issues.`;
    }
    
    if (normalizedQuery.includes('owner') || normalizedQuery.includes('who owns')) {
      return `${selectedProject.name} is owned by ${selectedProject.owner}.`;
    }
    
    if (normalizedQuery.includes('last scan') || normalizedQuery.includes('when was it scanned')) {
      return `The last security scan for ${selectedProject.name} was performed on ${selectedProject.lastScan}.`;
    }
    
    if (normalizedQuery.includes('status') || normalizedQuery.includes('state')) {
      return `${selectedProject.name} currently has a status of "${selectedProject.status}".`;
    }
    
    if (normalizedQuery.includes('description') || normalizedQuery.includes('what is it')) {
      return `${selectedProject.name}: ${selectedProject.description}`;
    }
    
    return `You asked about ${selectedProject.name}. Please specify what information you need about this project (vulnerabilities, owner, status, etc).`;
  }
  
  // General fallback responses
  if (normalizedQuery.includes('hello') || normalizedQuery.includes('hi ')) {
    return 'Hello! I can help you with information about Checkmarx security projects. What would you like to know?';
  }
  
  if (normalizedQuery.includes('help')) {
    return 'I can provide information about Checkmarx security projects. You can ask me to list all projects, select a specific project, or ask about vulnerabilities, owners, status, and more for a selected project.';
  }
  
  return "I'm not sure I understand your question. You can ask me to list projects, select a specific project, or ask about project details like vulnerabilities, owners, or status.";
};

export const createNewMessage = (content: string, role: 'user' | 'assistant'): Message => {
  return {
    id: Math.random().toString(36).substring(2, 9),
    content,
    role,
    timestamp: new Date()
  };
};

export const getSelectedProject = (messages: Message[]): Project | null => {
  // Analyze messages to determine which project is selected
  for (const message of messages) {
    if (message.role === 'assistant') {
      const match = message.content.match(/I've selected project .+ \((PRJ-\d+)\)/);
      if (match && match[1]) {
        const projectId = match[1];
        return mockProjects.find(p => p.id === projectId) || null;
      }
    }
  }
  return null;
};
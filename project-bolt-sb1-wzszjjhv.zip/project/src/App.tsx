import React, { useState, useEffect } from 'react';
import NavBar from './components/NavBar';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';
import ProjectInfo from './components/ProjectInfo';
import SuggestedQuestions from './components/SuggestedQuestions';
import { ChatState, Message } from './types';
import { createNewMessage, generateResponse, getSelectedProject } from './utils/chatUtils';
import { ShieldAlert, Activity, Shield } from 'lucide-react';

function App() {
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    selectedProject: null
  });

  // Helper to add a new message to the chat
  const addMessage = (content: string, role: 'user' | 'assistant') => {
    const newMessage = createNewMessage(content, role);
    setChatState(prevState => ({
      ...prevState,
      messages: [...prevState.messages, newMessage]
    }));
    return newMessage;
  };

  // Update selected project based on message content
  useEffect(() => {
    if (chatState.messages.length > 0) {
      const project = getSelectedProject(chatState.messages);
      if (project !== chatState.selectedProject) {
        setChatState(prevState => ({
          ...prevState,
          selectedProject: project
        }));
      }
    }
  }, [chatState.messages]);

  // Handle sending a message
  const handleSendMessage = (content: string) => {
    // Add user message
    addMessage(content, 'user');
    
    // Set loading state
    setChatState(prevState => ({
      ...prevState,
      isLoading: true
    }));
    
    // Simulate API delay
    setTimeout(() => {
      // Generate and add AI response
      const response = generateResponse(content, chatState.selectedProject);
      addMessage(response, 'assistant');
      
      // Clear loading state
      setChatState(prevState => ({
        ...prevState,
        isLoading: false
      }));
    }, 600);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <NavBar />
      
      <div className="flex-1 container mx-auto px-4 py-6 flex gap-6 overflow-hidden">
        <div className="flex flex-col flex-1 bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
          <div className="bg-gray-50 border-b border-gray-200 p-4">
            <h2 className="text-xl font-semibold text-gray-800">Project Assistant</h2>
            <p className="text-sm text-gray-600">
              Ask questions about your Checkmarx projects and security scans
            </p>
          </div>
          
          <ChatHistory 
            messages={chatState.messages} 
            isLoading={chatState.isLoading} 
          />
          
          <SuggestedQuestions onSelectQuestion={handleSendMessage} />
          
          <div className="p-4 border-t border-gray-200">
            <ChatInput 
              onSendMessage={handleSendMessage} 
              isLoading={chatState.isLoading} 
            />
          </div>
        </div>
        
        <aside className="hidden lg:block w-80 space-y-6">
          {chatState.selectedProject ? (
            <ProjectInfo project={chatState.selectedProject} />
          ) : (
            <div className="bg-white rounded-lg shadow p-6 space-y-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Checkmarx Security Dashboard
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="mr-4 p-3 bg-red-100 rounded-full">
                    <ShieldAlert size={24} className="text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Critical Vulnerabilities</p>
                    <p className="text-xl font-semibold">11</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="mr-4 p-3 bg-blue-100 rounded-full">
                    <Activity size={24} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Active Projects</p>
                    <p className="text-xl font-semibold">5</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="mr-4 p-3 bg-green-100 rounded-full">
                    <Shield size={24} className="text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Scans Completed</p>
                    <p className="text-xl font-semibold">27</p>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600 mb-2">Recent Activity</p>
                <ul className="space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-gray-600">Mobile Banking App</span>
                    <span className="text-gray-500">2h ago</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Payment API</span>
                    <span className="text-gray-500">5h ago</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Customer Identity</span>
                    <span className="text-gray-500">1d ago</span>
                  </li>
                </ul>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

export default App;
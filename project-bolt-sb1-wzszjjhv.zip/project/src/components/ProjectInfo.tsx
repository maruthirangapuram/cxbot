import React from 'react';
import { Project } from '../types';
import { Shield, Calendar, User, AlertCircle } from 'lucide-react';

interface ProjectInfoProps {
  project: Project;
}

const ProjectInfo: React.FC<ProjectInfoProps> = ({ project }) => {
  const { high, medium, low } = project.vulnerabilities;
  const totalVulnerabilities = high + medium + low;
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">
          {project.name}
        </h3>
        <div className="text-sm bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded">
          {project.id}
        </div>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">{project.description}</p>
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-gray-50 p-3 rounded-md">
          <div className="flex items-center text-sm text-gray-600 mb-1">
            <Calendar size={16} className="mr-2" />
            Last Scan
          </div>
          <div className="font-medium">{project.lastScan}</div>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-md">
          <div className="flex items-center text-sm text-gray-600 mb-1">
            <User size={16} className="mr-2" />
            Owner
          </div>
          <div className="font-medium">{project.owner}</div>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center text-sm text-gray-600">
            <Shield size={16} className="mr-2" />
            Vulnerabilities
          </div>
          <div className="text-sm font-medium">{totalVulnerabilities} total</div>
        </div>
        
        <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
          {totalVulnerabilities > 0 && (
            <div className="h-full flex">
              {high > 0 && (
                <div 
                  className="bg-red-500 h-full"
                  style={{ width: `${(high / totalVulnerabilities) * 100}%` }}
                />
              )}
              {medium > 0 && (
                <div 
                  className="bg-orange-400 h-full"
                  style={{ width: `${(medium / totalVulnerabilities) * 100}%` }}
                />
              )}
              {low > 0 && (
                <div 
                  className="bg-yellow-300 h-full"
                  style={{ width: `${(low / totalVulnerabilities) * 100}%` }}
                />
              )}
            </div>
          )}
        </div>
        
        <div className="flex mt-2 text-xs gap-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div>
            <span>High: {high}</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-400 rounded-full mr-1"></div>
            <span>Medium: {medium}</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-yellow-300 rounded-full mr-1"></div>
            <span>Low: {low}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center">
        <div className="flex items-center mr-3">
          <AlertCircle size={16} className="mr-1 text-gray-500" />
          <span className="text-sm">Status:</span>
        </div>
        <div 
          className={`text-sm font-medium px-2 py-1 rounded ${
            project.status === 'Completed' 
              ? 'bg-green-100 text-green-800' 
              : project.status === 'In Progress' 
                ? 'bg-blue-100 text-blue-800' 
                : 'bg-red-100 text-red-800'
          }`}
        >
          {project.status}
        </div>
      </div>
    </div>
  );
};

export default ProjectInfo;
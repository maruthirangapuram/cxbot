import React from 'react';
import { ShieldCheck } from 'lucide-react';

const NavBar: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <ShieldCheck size={28} className="mr-2" />
          <h1 className="text-xl font-bold">Checkmarx Assistant</h1>
        </div>
        
        <nav>
          <ul className="flex space-x-6">
            <li>
              <a href="#" className="text-white opacity-90 hover:opacity-100 text-sm">Projects</a>
            </li>
            <li>
              <a href="#" className="text-white opacity-90 hover:opacity-100 text-sm">Reports</a>
            </li>
            <li>
              <a href="#" className="text-white opacity-90 hover:opacity-100 text-sm">Settings</a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default NavBar;
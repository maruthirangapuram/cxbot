import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [inputValue, setInputValue] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (inputValue.trim() && !isLoading) {
      onSendMessage(inputValue);
      setInputValue('');
    }
  };
  
  return (
    <form 
      onSubmit={handleSubmit}
      className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg p-2 shadow-sm"
    >
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Ask about Checkmarx projects..."
        className="flex-1 py-2 px-3 outline-none text-gray-700"
        disabled={isLoading}
      />
      <button 
        type="submit"
        disabled={!inputValue.trim() || isLoading}
        className={`p-2 rounded-md ${
          inputValue.trim() && !isLoading
            ? 'bg-blue-600 text-white hover:bg-blue-700' 
            : 'bg-gray-200 text-gray-500 cursor-not-allowed'
        }`}
      >
        <Send size={20} />
      </button>
    </form>
  );
};

export default ChatInput;
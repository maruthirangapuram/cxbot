import React from 'react';

interface SuggestedQuestionsProps {
  onSelectQuestion: (question: string) => void;
}

const SuggestedQuestions: React.FC<SuggestedQuestionsProps> = ({ onSelectQuestion }) => {
  const suggestions = [
    "List all projects",
    "What vulnerabilities are in PRJ-002?",
    "Who owns the Mobile Banking App?",
    "When was the last scan for PRJ-001?",
    "Tell me about project PRJ-005"
  ];
  
  return (
    <div className="p-3 bg-gray-50 border-t border-gray-200">
      <p className="text-xs text-gray-500 mb-2">Suggested questions:</p>
      <div className="flex flex-wrap gap-2">
        {suggestions.map((question, index) => (
          <button
            key={index}
            onClick={() => onSelectQuestion(question)}
            className="text-xs bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 py-1 px-2 rounded-full transition-colors"
          >
            {question}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SuggestedQuestions;
export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  lastScan: string;
  vulnerabilities: {
    high: number;
    medium: number;
    low: number;
  };
  status: 'Completed' | 'In Progress' | 'Failed';
  owner: string;
  created: string;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  selectedProject: Project | null;
}